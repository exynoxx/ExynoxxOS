#ifndef CBUFFER_H
#define CBUFFER_H

void cbuffer_init ();
void cbuffer_add (unsigned int addr, unsigned int n);
unsigned int cbuffer_get (unsigned int n);


#endif