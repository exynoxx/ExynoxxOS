#ifndef TAR_H
#define TAR_H

void tar_init (unsigned int address);

#endif