#include <multiboot.h>
#include "pmm.h"
#include "cbuffer.h"
#include "libc.h"

extern int end;
unsigned int kernel_end = (unsigned int) &end;

// MULTIBOOT MEM COLLECTER
void find_space (struct multiboot *mboot)
{
    unsigned int i = mboot->mmap_addr;
    unsigned int page_count = 0;
    unsigned int entries = 0;
    
    while (i < (u32)mboot->mmap_addr + (u32)mboot->mmap_length)
    {
        multiboot_mmap *block = (multiboot_mmap *) i;
        
        // Does this entry specify usable RAM?
        if (block->type == 1)
        {
            (block->base_addr_low + 0x1000) & 0xfffff000;
            
            if (block->base_addr_low < 0x400000 && block->length_low > 0x400000) {
                block->length_low -= ((block->base_addr_low + block->base_addr_low) - 0x400000);
                block->base_addr_low = 0x400000;
                
                pmm_push_m (block->base_addr_low, (block->length_low / 0x1000) - 0x1000);
                page_count += (block->length_low / 0x1000) - 0x1000;
                entries++;
            }
            
        }
        
        // The multiboot specification is strange in this respect - the size member does not include "size" itself in its calculations,
        // so we must add sizeof (uint32_t).
        i += block->size + sizeof (unsigned int);
    }
    printk ("[pmm] Added %i pages | %i entries\n", page_count, entries);
}

void pmm_push_m (unsigned int addr, unsigned int n)
{
    cbuffer_add (addr, n);
}

void pmm_push (unsigned int addr)
{
    cbuffer_add (addr, 1);
}

unsigned int pmm_pop_m (unsigned int n)
{
    return cbuffer_get (n);
}

unsigned int pmm_pop ()
{
    return cbuffer_get (1);
}

void pmm_init (struct multiboot *mboot)
{
    cbuffer_init ();
    find_space (mboot);
    
    
    printk("[pmm] init\n");
}

/*
 
 // MULTIBOOT MEM COLLECTER
 void find_space (struct multiboot *mboot)
 {
 unsigned int i = mboot->mmap_addr;
 unsigned int page_count = 0;
 unsigned int entries = 0;
 
 while (i < (u32)mboot->mmap_addr + (u32)mboot->mmap_length)
 {
 multiboot_mmap *block = (multiboot_mmap *) i;
 
 // Does this entry specify usable RAM?
 if (block->type == 1)
 {
 (block->base_addr_low + 0x1000) & 0xfffff000;
 
 if (block->base_addr_low > 0x100000 && block->base_addr_low < (kernel_end + 0x1000)) {
 i += block->size + sizeof (unsigned int);
 continue;
 }
 
 pmm_push_m (block->base_addr_low, (block->length_low / 0x1000));
 page_count += block->length_low / 0x1000;
 entries++;
 }
 
 // The multiboot specification is strange in this respect - the size member does not include "size" itself in its calculations,
 // so we must add sizeof (uint32_t).
 i += block->size + sizeof (unsigned int);
 }
 printk ("[pmm] Added %i pages | %i entries\n", page_count, entries);
 }
 */
