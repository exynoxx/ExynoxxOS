#ifndef PMM_H
#define PMM_H

void            pmm_push_m (unsigned int addr, unsigned int n);
void            pmm_push (unsigned int addr);
unsigned int    pmm_pop_m (unsigned int n);
unsigned int    pmm_pop ();
void            pmm_init (struct multiboot *mboot);

#endif