#include "libc.h"
#include "dt.h"
#include "interrupt.h"
#include "monitor.h"
#include "task.h"
#include "pit.h"
#include <multiboot.h>
#include "heap.h"
#include "cbuffer.h"
#include "tar.h"

int aa = 0;
int bb = 0;
int cc = 0;

void a ()
{
    unsigned int allo = 1;
    while (1){
        if (aa == 0) {
            printk ("a.");
            aa = 1;
            bb = 0;
            
            if (allo) {
                //vmm_map_pt (vmm_get_current_pd (), 0xC0000000, 0xa00000);
                unsigned int *hello = (unsigned int *) malloc (4);
                *hello = 100;
                
                printk ("malloc: %x is = %i", hello, *hello);
                allo = 0;
            }
        }
    }
}
void b ()
{
    while (1){
        if (bb == 0) {
            printk ("b.");
            bb = 1;
            cc = 0;
        }
        
    }
}
void c ()
{
    unsigned int activated = 0;
    while (1){
        if (cc == 0) {
            printk ("c.");
            cc = 1;
            aa = 0;
        }
    }
}

void main(struct multiboot *mboot)
{
    gdt_install();
    idt_install();
    interrupt_install();
    monitor_clear();
    
    //printk ("[kernel] size: %i\n", kernel_end - 0x00100000);
    
    pit_init (50);
    pmm_init (mboot);
    //vmm_init ();
    //heap_init (0xC0000000);
    
    //task TEST
    /*
    task_init ();
    task_create (a);
    task_create (b);
    task_create (c);
    task_start ();
    */
    
    /*
    unsigned int *a = (unsigned int *) 0xC0000000;
    unsigned int *b = (unsigned int *) 0xD0000000;
    unsigned int c = pmm_pop_m (100);
    printk ("c: %x\n", c);
    //printk ("pmm pop: %x\n", pmm_pop_m (1024));
    
    
    vmm_map_pt (0,a,c);
    vmm_map_pt (0,b,c);
    
    *a = 501;
    printk ("b: %i\n", *b);
    *b = 456;
    printk ("a: %i\n", *a);
    */
    
    printk ("[multiboot] mods: %i\n", mboot->mods_count);
    printk ("[multiboot] mods addr: %x\n", mboot->mods_addr);
    
    multiboot_mod *mod = (multiboot_mod *) mboot->mods_addr;
    printk ("[multiboot] mod start: %x\n",mod->mod_start);
    printk ("[multiboot] mod end: %x\n",mod->mod_end);
    printk ("[multiboot] mod length: %i\n", mod->mod_end - mod->mod_start);
    tar_init (mod->mod_start);
     
    
    /*
    //HEAP TEST
    unsigned int *a = (unsigned int *) malloc (4);
    *a = 500;
    unsigned int *b = (unsigned int *) malloc (4);
    unsigned int *c = (unsigned int *) malloc (4);
    
    printk ("a: %x\nb: %x\nc: %x\n",a,b,c);
    
    free(c);
    unsigned int *d = (unsigned int *) malloc (4);
    
    printk ("d: %x\n", d);
    */
    
    
    for (;;);
}
