#include "tar.h"

struct tar_header
{
    char filename[100];
    char mode[8];
    char uid[8];
    char gid[8];
    char size[12];
    char mtime[12];
    char chksum[8];
    char typeflag[1];
} __attribute__ ((packed));

unsigned char ascii_table [123] = {
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0, //20
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0, //40
    0,0,0,0,0,0,0,0,
    '0','1','2','3','4','5','6','7','8','9',':',';',
    '<','=','>','?','@',
    'A','B','C','D','E','F','G','H','I','J','K'
    ,'L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'
    ,0,0,0,0,0,0,
    'a','b','c','d','e','f','g','h','i','j','k','l','m','n',
    'o','p','q','r','s','t','u','v','w','x','y','z'
};

struct tar_header *headers[8];

unsigned int getsize(const char *in)
{
    
    unsigned int size = 0;
    unsigned int j;
    unsigned int count = 1;
    
    for (j = 11; j > 0; j--, count *= 8)
        size += ((in[j - 1] - '0') * count);
    
    return size;
    
}

unsigned int parse(unsigned int address)
{
    
    struct tar_header *header = (struct tar_header *)address;
    
    unsigned int size = getsize(header->size);
    printk ("---------------------\n");
    printk ("[tar] file size: %i\n\n", size);

    char *content = (char *) address + 512;
    printk ("%s\n", content);
    printk ("---------------------\n");
    
    
    /*
    
    unsigned int i;
    
    for (i = 0; ; i++)
    {
        
        struct tar_header *header = (struct tar_header *)address;
        printk ("[tar] test file size: %i\n", getsize(header->size));
        
        header += 512;
        char *a = (char *) header;
        printk ("string: %s\n", a);
        printk ("file: %c\n", header->filename[0]);
        printk ("file: %c\n", header->filename[1]);
        printk ("file: %c\n", header->filename[2]);
        printk ("file: %c\n", header->filename[3]);
        printk ("file: %c\n", header->filename[4]);
        printk ("file: %c\n", header->filename[5]);
        
        
        if (header->filename[0] == '\0')
            break;
        
        unsigned int size = getsize(header->size);
        
        headers[i] = header;
        
        address += ((size / 512) + 1) * 512;
        
        if (size % 512)
            address += 512;
        
    }
    
    return i;
     */
}

void tar_init (unsigned int address)
{
    unsigned int nfiles = parse (address);
    printk ("[tar] found %i files\n", parse (address));
    
    //////////////////////////////
    /*
    unsigned int start = 0x1080c0;
    unsigned int len = 300;
    
    unsigned int i = 1;
    for (unsigned char *a = (unsigned char *) start; a < start + len; a++) {
        
        printk ("%c", ascii_table[*a]);
        
        if (i > 20)
        {
            printk ("\n");
            printk (":%x:", a);
            i = 1;
        }
        i++;
    }
    */
    
    
    

    printk ("done");
}
