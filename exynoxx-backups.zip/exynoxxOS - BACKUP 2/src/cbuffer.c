#include "cbuffer.h"

extern int end;
unsigned int kernelend = (unsigned int) &end;

/* cbuffer = circular buffer
 */

typedef struct {
    unsigned int address;
    unsigned int amount;
} cbuff_entry;

cbuff_entry *selector_add;
cbuff_entry *selector_get;
unsigned int cbuffer_bottom;

void cbuffer_init ()
{
    cbuffer_bottom = (unsigned int) ((kernelend + 0x1000) & 0xfffff000);
    selector_get = selector_add = (cbuff_entry *) cbuffer_bottom;
    
    printk("[cbuffer] init\n");
}

cbuff_entry *increment (cbuff_entry *x)
{
    if ((unsigned int) x > cbuffer_bottom + 0x1000)
        x = (cbuff_entry *) cbuffer_bottom;
    else
        x += sizeof (cbuff_entry);
    return x;
}

void cbuffer_add (unsigned int addr, unsigned int n)
{
    cbuff_entry *new = selector_add;
    new->address = addr;
    new->amount = n;
    
    selector_add = increment (selector_add);
}

/*
unsigned int cbuffer_get ()
{
    //unsigned int n;
    
    while (selector_get->amount == 0)
    {
        selector_get = increment (selector_get);
        
        //put error handler here
    }
    
    //addr + (n-1) * 0x1000
    unsigned int page = (unsigned int)(selector_get->address + (selector_get->amount - 1) * 0x1000);
    selector_get->amount--;
    
    return page;
}
 */

unsigned int cbuffer_get (unsigned int n)
{
    while (selector_get->amount < n)
        selector_get = increment (selector_get);
    
    unsigned int page = (unsigned int)(selector_get->address + (selector_get->amount - n) * 0x1000);
    selector_get->amount -= n;
    
    return page;
}
