#include "elf.h"

struct elf_header {
    unsigned int magic;
    unsigned int class      : 1; //1=32bit, 2=64bit
    unsigned int endian     : 1; //1=little, 2=big
    unsigned int version    : 1;
    unsigned int os_abi     : 1;
    unsigned int abi_version: 1;
    unsigned int unused     : 7;
    unsigned int type       : 2;
    unsigned int machine    : 2;
    unsigned int version2;
    unsigned int entry;
    unsigned int phoff;
    unsigned int shoff;
    unsigned int flags;
    unsigned int ehsize;    : 2;
    unsigned int phentsize  : 2;
    unsigned int phnum      : 2;
    unsigned int shentsize  : 2;
    unsigned int shnum      : 2;
    unsigned int shstrndx   : 2;
    
};