#include <multiboot.h>
#include "pmm.h"
#include "libc.h"

unsigned int bitmap[32];
unsigned int offset;

/*
void find_space (struct multiboot *mboot)
{
    unsigned int i = mboot->mmap_addr;
    unsigned int page_count = 0;
    unsigned int entries = 0;
    
    while (i < (u32)mboot->mmap_addr + (u32)mboot->mmap_length)
    {
        multiboot_mmap *block = (multiboot_mmap *) i;
        
        printk ("|%i| From %x to %x - size: %x\n", block->type, block->base_addr_low, block->length_low+block->base_addr_low, block->length_low);
        
        
        
        // The multiboot specification is strange in this respect - the size member does not include "size" itself in its calculations,
        // so we must add sizeof (uint32_t).
        i += block->size + sizeof (unsigned int);
    }
    //printk ("[pmm] Added %i pages | %i entries\n", page_count, entries);
}
 */

//dosent work yet
void pmm_free (unsigned int addr)
{
    unsigned int i = 0;
    unsigned int j = 0;
    addr -= offset;
    
    i = (addr / 4096) / 32;
    j = (addr - (i * 32 * 4096)) / 4096;
    
    bitmap[i] &= ~(1 << j);
}

unsigned int pmm_alloc ()
{
    unsigned int i = 0;
    unsigned int j = 0;
    
    while(bitmap[i] == 0xFFFFFFFF)
    {
        i++;
    }
    
    for (; j <= 31; j++) {
        if ((bitmap[i] & (1 << j)) == 0)
        {
            break;
        }
    }
    
    bitmap[i] |= (1 << j); //(set bit) this area is now reserved
    
    return offset + ((i * 32) + j) * 4096;
}

void pmm_init (multiboot_mod *mod)
{
    offset = mod->mod_end;
    //find_space (mboot);
    
    printk("[pmm] init\n");
    //return m->mod_start;
}