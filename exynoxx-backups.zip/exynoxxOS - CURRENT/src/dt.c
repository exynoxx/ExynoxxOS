
#include "dt.h"

struct gdt_entry
{
    unsigned short limit_low;
    unsigned short base_low;
    unsigned char base_middle;
    unsigned char access;
    unsigned char granularity;
    unsigned char base_high;
} __attribute__((packed));

struct gdt_ptr
{
    unsigned short limit;
    unsigned int base;
} __attribute__((packed));

struct idt_entry
{
    unsigned short base_lo;
    unsigned short sel;
    unsigned char always0;
    unsigned char flags;
    unsigned short base_hi;
} __attribute__((packed));

struct idt_ptr
{
    unsigned short limit;
    unsigned int base;
} __attribute__((packed));

struct idt_entry idt[256];
struct gdt_entry gdt[6];
struct idt_ptr idtp;
struct gdt_ptr gp;
tss_entry tss;
extern void idt_load();
extern void gdt_flush();
extern void tss_flush();

void gdt_set_gate(int num, unsigned long base, unsigned long limit, unsigned char access, unsigned char gran)
{
    gdt[num].base_low = (base & 0xFFFF);
    gdt[num].base_middle = (base >> 16) & 0xFF;
    gdt[num].base_high = (base >> 24) & 0xFF;
    
    gdt[num].limit_low = (limit & 0xFFFF);
    gdt[num].granularity = ((limit >> 16) & 0x0F);
    
    gdt[num].granularity |= (gran & 0xF0);
    gdt[num].access = access;
}

void gdt_install()
{
    gp.limit = (sizeof(struct gdt_entry) * 6) - 1;
    gp.base = &gdt;
    gdt_set_gate(0, 0, 0, 0, 0);
    gdt_set_gate(1, 0, 0xFFFFFFFF, 0x9A, 0xCF); //krn cs
    gdt_set_gate(2, 0, 0xFFFFFFFF, 0x92, 0xCF); //krn ds
    gdt_set_gate(3, 0, 0xFFFFFFFF, 0xFA, 0xCF); //user cs
    gdt_set_gate(4, 0, 0xFFFFFFFF, 0xF2, 0xCF); //user ds
    write_tss(5, 0x10, 0x0);
    
    gdt_flush();
    tss_flush ();
}

void idt_set_gate(unsigned char num, unsigned long base, unsigned short sel, unsigned char flags)
{
    idt[num].base_lo = (base & 0xFFFF);
    idt[num].base_hi = (base >> 16) & 0xFFFF;
    idt[num].sel = sel;
    idt[num].always0 = 0;
    idt[num].flags = flags;
}

void idt_install()
{
    idtp.limit = (sizeof (struct idt_entry) * 256) - 1;
    idtp.base = &idt;
    memset(&idt, 0, sizeof(struct idt_entry) * 256);
    idt_load();
}

static void write_tss(int num, unsigned short ss0, unsigned int esp0)
{
    unsigned int base = (unsigned int) &tss;
    unsigned int limit = base + sizeof(tss_entry);
    
    gdt_set_gate(num, base, limit, 0xE9, 0x00);
    memset(&tss, 0, sizeof(tss_entry));
    
    tss.ss0  = ss0;
    tss.esp0 = esp0;
    tss.cs   = 0x0b;
    tss.ss = tss.ds = tss.es = tss.fs = tss.gs = 0x13;
}

void set_kernel_stack(unsigned int stack)
{
    tss.esp0 = stack;
}
