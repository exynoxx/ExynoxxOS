#ifndef SYSCALL_H
#define SYSCALL_H

void syscall_handler ();

#endif