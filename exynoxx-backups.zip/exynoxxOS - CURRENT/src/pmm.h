#ifndef PMM_H
#define PMM_H

#include <multiboot.h>

void         pmm_free (unsigned int addr);
unsigned int pmm_alloc ();
void         pmm_init (multiboot_mod *mod);

#endif