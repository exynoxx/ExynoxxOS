#include "syscall.h"

void syscall_handler ()
{
    printk ("syscall handled\n");
}