#include "libc.h"
#include "dt.h"
#include "interrupt.h"
#include "monitor.h"
#include "task.h"
#include "pit.h"
#include <multiboot.h>
#include "heap.h"
#include "tar.h"

int aa = 1;
int bb = 0;
int cc = 0;

void usertest ()
{
    printk ("hello there\n");
    
    //unsigned int *a = (unsigned int *) malloc (4);
    //*a = 500;
    
    __asm volatile("int $0x80");
    
    while (1) {
        
    }
    
    
    
     
}

void a ()
{
    while (1){
        
        if (aa) {
            printk ("a.");
            aa = 0;
            bb = 1;
        }
    }
}
void b ()
{
    while (1){
        if (bb) {
            printk ("b.");
            bb = 0;
            cc = 1;
            
        }
        
    }
}
void c ()
{
    
    while (1){
        if (cc) {
            printk ("c.");
            cc = 0;
            aa = 1;
        }
    }
}

void main(struct multiboot *mboot, unsigned int esp)
{
    set_kernel_stack (esp);
    gdt_install();
    idt_install();
    interrupt_install();
    monitor_clear();
    
    printk ("Stack: %x\n", esp);
    
    pit_init (200);              /*  PIT  */
    tar_init (mboot->mods_addr); /*  HDD  */
    pmm_init (mboot->mods_addr); /*  PMM  */
    vmm_init ();                 /*  VMM  */
    
    
    multiboot_mod *mod = (multiboot_mod *) mboot->mods_addr;
    unsigned int addr_phys = mod->mod_end + 0x1000 * 1024;
    vmm_map_pt (0, 0xC0000000, addr_phys);
    heap_init (0xC0000000);
    
    
    //unsigned int esp1;
    //__asm__ __volatile__ ("mov %%esp, %0" : "=r" (esp1));
    //printk ("stack size: %i\n", esp-esp1);
    
    /*
    task_init (addr_phys);
    task_create (a);
    task_create (b);
    task_create (c);
    //task_start ();
     */
    
    jump_usermode ();
    
    
    

    
    
    
    
    
    
    
    
    
    /*
     printk ("%x\n", pmm_alloc ());
     printk ("%x\n", pmm_alloc ());
     printk ("%x\n", pmm_alloc ());
     printk ("%x\n", pmm_alloc ());
     */
    
    
    //HEAP TEST
    /*
    unsigned int *a = (unsigned int *) malloc (4);
    *a = 500;
    unsigned int *b = (unsigned int *) malloc (4);
    unsigned int *c = (unsigned int *) malloc (4);
    
    printk ("a: %x\nb: %x\nc: %x\n",a,b,c);
    
    free(c);
    unsigned int *d = (unsigned int *) malloc (4);
    
    printk ("d: %x\n", d);
    
    */
    
    for (;;);
}
