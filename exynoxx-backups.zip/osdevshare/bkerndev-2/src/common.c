#include <system.h>

// Write a byte out to the specified port.
void outb(unsigned short port, unsigned char value)
{
    __asm volatile ("outb %1, %0" : : "dN" (port), "a" (value));
}

void outw (unsigned short port, unsigned short value)
{
    __asm volatile ("outw %1, %0" : : "dN" (port), "a" (value));
}

void outl (unsigned short port, unsigned int value)
{
    __asm volatile ("outl %1, %0" : : "dN" (port), "a" (value));
}

unsigned char inb(unsigned short port)
{
    unsigned char ret;
    __asm volatile("inb %1, %0" : "=a" (ret) : "dN" (port));
    return ret;
}

unsigned short inw(unsigned short port)
{
    unsigned short ret;
    __asm volatile ("inw %1, %0" : "=a" (ret) : "dN" (port));
    return ret;
}

unsigned int inl (unsigned short port)
{
    unsigned int ret;
    __asm volatile("inl %1, %0" : "=a" (ret) : "dN" (port));
    return ret;
}

// Copy len bytes from src to dest.
void memcpy(unsigned char *dest, const unsigned char *src, unsigned int len)
{
    const unsigned char *sp = (const unsigned char *)src;
    unsigned char *dp = (unsigned char *)dest;
    for(; len != 0; len--) *dp++ = *sp++;
}

// Write len copies of val into dest.
void memset(unsigned char *dest, unsigned char val, unsigned int len)
{
    unsigned char *temp = (unsigned char *)dest;
    for ( ; len != 0; len--) *temp++ = val;
}

unsigned short *memsetw(unsigned short *dest, unsigned short val, size_t count)
{
    unsigned short *temp = (unsigned short *)dest;
    for( ; count != 0; count--) *temp++ = val;
    return dest;
}
// Compare two strings. Should return -1 if
// str1 < str2, 0 if they are equal or 1 otherwise.
int strcmp(char *str1, char *str2)
{
    int i = 0;
    int failed = 0;
    while(str1[i] != '\0' && str2[i] != '\0')
    {
        if(str1[i] != str2[i])
        {
            failed = 1;
            break;
        }
        i++;
    }
    // why did the loop exit?
    if( (str1[i] == '\0' && str2[i] != '\0') || (str1[i] != '\0' && str2[i] == '\0') )
        failed = 1;
    
    return failed;
}

// Copy the NULL-terminated string src into dest, and
// return dest.
char *strcpy(char *dest, const char *src)
{
    do
    {
        *dest++ = *src++;
    }
    while (*src != 0);
}

// Concatenate the NULL-terminated string src onto
// the end of dest, and return dest.
char *strcat(char *dest, const char *src)
{
    while (*dest != 0)
    {
        *dest = *dest++;
    }
    
    do
    {
        *dest++ = *src++;
    }
    while (*src != 0);
    return dest;
}

int strlen(char *src)
{
    int i = 0;
    while (*src++)
        i++;
    return i;
}

void sti ()
{
    __asm volatile ("sti");
}
void cli ()
{
    __asm volatile ("cli");
}

void sitoa( char *buf, int base, int d )
{
    char *p = buf;
    char *p1, *p2;
    unsigned long ud = d;
    int divisor = 10;
    
    if(base == 10 && d < 0)
    {
        *p++ = '-';
        buf++;
        ud = -d;
        
    }
    else if(base == 16)
        divisor = 16;
    else if ( base == 2 )
    {
        divisor = base;
        
    }
    
    do
    {
        int remainder = ud % divisor;
        
        *p++ = (remainder < 10) ? remainder + '0' : remainder + 'a' - 10;
        //length--;
    }
    while(ud /= divisor);
    *p = 0;
    
    p1 = buf;
    p2 = p - 1;
    while(p1 < p2)
    {
        char tmp = *p1;
        
        *p1 = *p2;
        *p2 = tmp;
        p1++;
        p2--;
    }
}


void str_strncpy( char *dest, char *src, int off, unsigned int len )
{
    char *d, *s;
    int i;
    
    d = dest; s = src;
    for (i = 0; i < off; i++)
        *(s++);	// move up to offset
    for( i = 0; i < len; i++)
        *(d++) = *(s++);
    
}


void split(char *output, char *str, char ch, int section)
{
    int i;
    for (i = 0; i < strlen(str); i++)
        if (str[i] == ch)
            break;
    
    if (section == 0) {
        str_strncpy(output, str, 0, i);
    } else {
        str_strncpy(output, str, i + 1, strlen(str) - i);
    }
}

