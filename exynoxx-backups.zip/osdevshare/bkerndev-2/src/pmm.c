#include <system.h>

extern unsigned int end;
unsigned int placement_address = (unsigned int) &end;

unsigned int malloc (unsigned int size)
{
    placement_address &= 0xFFFFF000;
    placement_address += 0x1000;
    
    unsigned int ret = placement_address;
    placement_address += size;
    return ret;
}