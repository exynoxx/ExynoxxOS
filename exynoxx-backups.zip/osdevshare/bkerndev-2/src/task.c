#include <system.h>

unsigned current_task = 0;
unsigned active_tasks = 0;
extern unsigned sched_started;

int task_init()
{
    unsigned i;
    
    for(i = 0; i < SCHEDULAR_TASKS; i++)
        task_list[i].state = TS_NULL;
    
    sched_started = 0;
    return 1;
}

int sched_find_free()
{
    int i;
    
    for(i = 0; i < SCHEDULAR_TASKS; i++)
        if(task_list[i].state == TS_NULL)
            return i;
    return -1;
}

void task_create (void *entry)
{
    if(entry == 0)
        return;
    
    __asm volatile ("cli");
    
    unsigned p = sched_find_free();
    
    if(p == -1)
        return;
    
    task_list[p].state = TS_READY;
    task_list[p].regs.eip = (unsigned int) entry;
    task_list[p].arch_data = 0;
    task_list[p].regs.eflags = 0x202;
    
    active_tasks++;
    
    if(active_tasks == 1)
        current_task = p;
    
    __asm volatile ("sti");
}

/*
void sched_exit()
{
    if(active_tasks == 0)
        return;
    
    arch_crit_start();
    
    task_list[current_task].state = TS_NULL;
    task_list[current_task].name[0] = 0;
    mm_free_by_pid(current_task);
    active_tasks--;
    
    arch_crit_end();
    for(;;);
}
*/



/** Go to next task */
void sched_next()
{
    //kprintf("switch\n");
    
    if(active_tasks == 0)
        return;
    
    /* Change task */
    if(++current_task >= (SCHEDULAR_TASKS-1))
        current_task = 0;
    
    
    while(task_list[current_task].state != TS_READY)
    {
        if(++current_task >= (SCHEDULAR_TASKS-1))
            current_task = 0;
    }
}

