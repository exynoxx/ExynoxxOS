/* bkerndev - Bran's Kernel Development Tutorial
*  By:   Brandon F. (friesenb@gmail.com)
*  Desc: Main.c: C code entry.
*
*  Notes: No warranty expressed or implied. Use at own risk. */
#include <system.h>
unsigned a = 0;
unsigned b = 0;
unsigned count = 0;

void task1 ()
{
    
    while (1)
    {
        
        if (a == 0) {
            printk ("p");
            count++;
            a = 1;
            b = 0;
        }
    }
}

void task2 ()
{
    while (1)
    {
        
        if (b == 0) {
            printk ("g# %i #", count);
            count++;
            b = 1;
            a = 0;
        }
    }
}

void main()
{
    gdt_install();
    idt_install();
    isrs_install();
    irq_install();
    init_video();
    //keyboard_install();
    task_init();
    timer_install();
    sti ();
    
    task_create (task1);
    task_create (task2);

    for (;;);
}
