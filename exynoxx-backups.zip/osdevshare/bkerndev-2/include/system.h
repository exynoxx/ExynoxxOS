/* bkerndev - Bran's Kernel Development Tutorial
*  By:   Brandon F. (friesenb@gmail.com)
*  Desc: Global function declarations and type definitions
*
*  Notes: No warranty expressed or implied. Use at own risk. */
#ifndef __SYSTEM_H
#define __SYSTEM_H

typedef int size_t;

/* This defines what the stack looks like after an ISR was running */
struct regs
{
    unsigned int gs, fs, es, ds;
    unsigned int edi, esi, ebp, esp, ebx, edx, ecx, eax;
    unsigned int int_no, err_code;
    unsigned int eip, cs, eflags, useresp, ss;    
};

typedef struct regs regs_t;

/* COMMON.C */
extern void outb(unsigned short port, unsigned char value);
extern void outw (unsigned short port, unsigned short value);
extern void outl (unsigned short port, unsigned int value);
extern unsigned char inb(unsigned short port);
extern unsigned short inw(unsigned short port);
extern unsigned int inl (unsigned short port);

extern void memcpy(unsigned char *dest, const unsigned char *src, unsigned int len);
extern void memset(unsigned char *dest, unsigned char val, unsigned int len);
unsigned short *memsetw(unsigned short *dest, unsigned short val, size_t count);
extern int strcmp(char *str1, char *str2);
extern char *strcpy(char *dest, const char *src);
extern char *strcat(char *dest, const char *src);
extern int strlen(char *src);
extern void sti ();
extern void cli ();
extern void sitoa( char *buf, int base, int d );
extern void split(char *output, char *str, char ch, int section);

/* CONSOLE.C */
extern void init_video(void);
extern void putch(unsigned char c);
extern void puts(unsigned char *text);
extern void putx (unsigned int n);
extern void cls();

/* PRINTK */
extern int printk( const char *fmt, ... );

/* GDT.C */
extern void gdt_set_gate(int num, unsigned long base, unsigned long limit, unsigned char access, unsigned char gran);
extern void gdt_install();

/* IDT.C */
extern void idt_set_gate(unsigned char num, unsigned long base, unsigned short sel, unsigned char flags);
extern void idt_install();

/* ISRS.C */
extern void isrs_install();

/* IRQ.C */
extern void irq_install_handler(int irq, void (*handler)(struct regs *r));
extern void irq_uninstall_handler(int irq);
extern void irq_install();

/* TIMER.C */
extern void timer_wait(int ticks);
extern void timer_install();

/* KEYBOARD.C */
extern void keyboard_install();

/* PMM */
extern unsigned int malloc (unsigned int size);

/* TASK.C */

#define SCHEDULAR_PTIME	10
#define SCHEDULAR_TICKS	10		///< Ticks to switch
#define SCHEDULAR_TASKS	30	///< Max number of tasks
typedef enum { TS_READY, TS_NULL } task_state_t;

/** Task structure */
typedef struct
{
    unsigned int		cpu;
    regs_t			regs;
    int			timer;
    
    void 			*arch_data;
    void			*base;
    unsigned int		size;
    
    task_state_t	state;
} task_t;

task_t 		task_list[SCHEDULAR_TASKS];		///< List of tasks

extern int task_init();
extern void task_create (void *entry);
extern void sched_next();



#endif
