#include "syscall.h"
#include "interrupt.h"
#include "monitor.h"

static void *syscalls[3] =
{
    &monitor_write,0,0
};

void syscall_handler (regs_t *r)
{
    //void *location = syscalls[r->eax];
    
    printk("syscall!");
}

void syscall_init ()
{
    interrupt_install_handler (0x80, syscall_handler);
}