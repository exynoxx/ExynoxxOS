#ifndef TASK_H
#define TASK_H

typedef enum {TASK_READY, TASK_NULL, TASK_DIE} task_state;
typedef struct _task task;

struct _task {
    unsigned char pid;
    task_state    state;
    unsigned int  user : 1;
    unsigned int  cr3;
    unsigned int  esp;
    unsigned int  esp0;
};

task            task_list[50];
void            task_create (void (*entry)());
unsigned int    get_current_task_id ();
void            task_start ();
void            task_stop ();
void            task_init ();

#endif