#include "heap.h"
#include "vmm.h"

unsigned int heap_start, index_alloc;

void free(void *mem)
{
    heap_block *alloc = (mem - sizeof(heap_block));
    alloc->status = 0;
}

char* mallocnew (unsigned int size)
{
    heap_block *alloc = (heap_block *) index_alloc;
    alloc->status = 1;
    alloc->size = size;
    
    index_alloc += size;
    index_alloc += sizeof(heap_block);
    
    return (char *)((unsigned int)alloc + sizeof(heap_block));
}

void* malloc(unsigned int size)
{
    void *mem = (void *) heap_start;
    while((unsigned int)mem < index_alloc)
    {
        heap_block *a = (heap_block *)mem;
        
        if(a->status) {
            mem += a->size;
            mem += sizeof(heap_block);
            continue;
        }
        
        if(a->size < size)
        {
            mem += a->size;
            mem += sizeof(heap_block);
            continue;
        }
        
        if ((unsigned int) a + size > (unsigned int)index_alloc)
            return mallocnew (size);
        
        a->status = 1;
        a->size = size;
        return (void *)(mem + sizeof(heap_block));
    }
    return mallocnew (size);
}

void heap_init ()
{
    unsigned int tmp = pmm_pop_pt ();
    vmm_map_pt (0, 0xC0000000, tmp);
    heap_start = index_alloc = 0xC0000000;
    vmm_flush_TLB ();
    
    printk ("[heap] init at: %x : %x\n", heap_start, tmp);
}
