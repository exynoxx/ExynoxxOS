#ifndef PMM_H
#define PMM_H

unsigned int    pmm_pop_pt  ();
unsigned int    pmm_pop     ();
void            pmm_push    (unsigned int addr, unsigned int size);

void            pmm_init (struct multiboot *mboot);

#endif