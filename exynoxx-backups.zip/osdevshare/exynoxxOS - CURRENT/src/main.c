#include "libc.h"
#include "dt.h"
#include "interrupt.h"
#include "monitor.h"
#include "task.h"
#include "pit.h"
#include <multiboot.h>
#include "heap.h"
#include <servers.h>
#include "syscall.h"

extern void jmp_usermode ();
unsigned int sstack;

void userfunc ()
{
    monitor_write ("hello");
    __asm volatile("int $0x80");
    
    while (1) {
    }
}

void main(struct multiboot *mboot, unsigned int esp)
{
    gdt_install();
    idt_install();
    interrupt_install();
    monitor_clear();
    
    //pit_init (50);
    pmm_init (mboot);
    vmm_init ();
    heap_init ();
    
    
    task_init ();
    task_create (a);
    task_create (b);
    task_create (c);
    task_create (server_mm);
    //task_start ();
    
    
    syscall_init ();
    
    /*
    unsigned int *a = (unsigned int *) malloc (4);
    unsigned int *b = (unsigned int *) malloc (4);
    unsigned int *c = (unsigned int *) malloc (4);
    *a = 1;
    *b = 1;
    *c = 1;
    printk ("a: %x\nb: %x\nc: %x\n",a,b,c);
    free (c);
    printk ("free\n");
    unsigned int d = (unsigned int) malloc (4);
    printk ("d: %x\n",d);
     */
    
    sstack = pmm_pop ();
    tss_set_stack (esp);
    
    jmp_usermode (userfunc);
    
    for (;;);
}

