#ifndef INTERRUPT_H
#define INTERRUPT_H

#include <regs.h>

void interrupt_install_handler(int n, void (*handler)(struct regs *r));
void interrupt_uninstall_handler(int n);
void interrupt_install();

#endif