#include "../src/monitor.h"
#include "../src/vmm.h"


void server_mm ()
{
    
    while (1) {
    }
}