#include "../src/monitor.h"
#include "../src/vmm.h"

unsigned int addr;

void a ()
{
    /*
    addr = pmm_pop_pt ();
    printk ("stat: %x\n", addr);
    vmm_map_pg (vmm_get_current_pd (), 0xd0000000, addr);
    vmm_flush_TLB ();
    
    
    unsigned int *tmp = (unsigned int *) 0xD0000000;
    *tmp = 500;
    printk ("a: %i\n", *tmp);
    */
    
    
    
    while (1){
    }
}
void b ()
{
    /*
    vmm_map_pg (vmm_get_current_pd (), 0xd0000000, addr);
    vmm_flush_TLB ();
    
    unsigned int *tmp = (unsigned int *) 0xD0000000;
    printk ("b: %i\n", *tmp);
    */
    while (1){
    }
    
}
void c ()
{
    while (1){
    }
}
