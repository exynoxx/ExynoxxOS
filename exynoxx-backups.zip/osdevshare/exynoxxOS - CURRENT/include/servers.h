#ifndef SERVER_H
#define SERVER_H

extern a ();
extern b ();
extern c ();
extern stat ();
extern void server_mm ();


#endif