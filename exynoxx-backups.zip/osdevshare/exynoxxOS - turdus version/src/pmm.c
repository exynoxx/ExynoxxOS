#include <multiboot.h>
#include "pmm.h"
#include "libc.h"

/*
 *  Using the turdus allocator
 *
 */

extern int end;
unsigned int kernel_end = (unsigned int) &end;
extern unsigned int vmm_started;
unsigned int *stack;
unsigned int poststack = 0;

void find_space (struct multiboot *mboot)
{
    unsigned int i = mboot->mmap_addr;
    unsigned int page_count = 0;
    
    while (i < (u32)mboot->mmap_addr + (u32)mboot->mmap_length)
    {
        multiboot_mmap *block = (multiboot_mmap *) i;
        if (block->type == 1)
        {
            unsigned int addr = (block->base_addr_low + 0x1000) & 0xfffff000;
            unsigned int pages = (block->length_low / 0x1000);
            page_count += pages;
            
            pmm_push (addr, pages);
        }
        i += block->size + sizeof (unsigned int);
    }
    printk ("[pmm] Added %i pages\n", page_count);
}

unsigned int pmm_pop_pt ()
{
    unsigned int *p = stack;
    p-=4;
    
    while (*p < 1024) {
        p-=8;
    }
    
    (*p) -= 1024;
    unsigned int n = *p;
    p-=4;
    
    //*p == pages
    unsigned int ret = (*p << 12);
    return ret + (0x1000 * n);
}

unsigned int pmm_pop ()
{
    
    if (!vmm_started) {
        return poststack += 0x1000;
    }
    
    unsigned int *p = stack;
    p-=4;
    
    check:
    if (*p == 1){
        p -= 8;
        stack -= 8;
        goto check;
    }
    
    //if no more pages -> new stack entry
    
    (*p)--;
    unsigned int n = *p;
    p-=4;
    
    //*p == pages
    unsigned int ret = (*p << 12);
    return ret + (0x1000 * n);
}

void pmm_push (unsigned int page, unsigned int size)
{
    unsigned int *p = stack;
    *p = (page >> 12);
    p += 4;
    *p = size;
    
    //fix stack
    stack += 8;
}

void pmm_init (struct multiboot *mboot)
{
    kernel_end += 0x1000;
    kernel_end &= 0xfffff000;
    
    stack = (unsigned int *) kernel_end;
    
    //find_space (mboot);
    
    pmm_push (0x400000, 2048);
    
    printk("[pmm] init\n");
    
    
}


