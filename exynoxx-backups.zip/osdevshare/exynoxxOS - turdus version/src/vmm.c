#include "pmm.h"
#include "vmm.h"

unsigned int *kernel_pd;
unsigned int *current_pd;
extern unsigned int kernel_end;
unsigned int vmm_started = 0;

void vmm_map_pt (unsigned int *pd, unsigned int virt, unsigned int phys)
{
    if (!pd) pd = kernel_pd;
    
    unsigned int id = virt >> 22;
    if (!pd[id])
        pd[id] = pmm_pop () | 0x3;
    
    unsigned int *pt = (unsigned int *) (pd[id] & 0xfffff000);
    for (unsigned int i = 0; i < 1024; i++) {
        pt[i] = (phys + (i * 0x1000)) | 0x3;
    }
}

void vmm_map_pg (unsigned int *pd, unsigned int virt, unsigned int phys)
{
    if (!pd) pd = kernel_pd;
    
    unsigned int pt_id = virt >> 22;
    unsigned int pg_id = (virt << 10) >> 22;
    
    if (!pd[pt_id]) pd[pt_id] = pmm_pop () | 0x3;
    
    unsigned int *pt = (unsigned int *) (pd[pt_id] & 0xfffff000);
    pt[pg_id] = phys | 0x3;
    //__asm volatile("invlpg %0" : : "m" (*(char*)virt));
}

void vmm_enable_paging ()
{
    unsigned int cr0;
    __asm volatile ("mov %%cr0, %0" : "=r" (cr0));
    cr0 |= 0x80000000;
    __asm volatile ("mov %0, %%cr0" : : "r" (cr0));
}

void vmm_page_fault (regs_t *r)
{
    unsigned int cr2;
    __asm volatile("mov %%cr2, %0" : "=r" (cr2));
    printk ("At cr2:        %x\n", cr2);
    printk ("eip:           %x\n", r->eip);
    printk ("fault type:    ");
    
    if(!(r->err_code & 0x1))
        printk("present ");
    if (r->err_code & 0x2)
        printk("rw ");
    if (r->err_code & 0x4)
        printk("us ");
    
    printk ("\n");
}

unsigned int *vmm_create_pd ()
{
    unsigned int *pd = (unsigned int *) pmm_pop ();
    pd[0] = pmm_pop () | 0x3;
    unsigned int *pt = (unsigned int *) (pd[0] & 0xfffff000);
    for (unsigned int i = 0; i < 1024; i++) {
        pt[i] = (i * 0x1000) | 0x3;
    }
    pd[1023] = (unsigned int) pd | 0x3;
    
    return pd;
}

void vmm_flush_TLB ()
{
    __asm volatile ("mov %cr3, %eax");
    __asm volatile ("mov %eax, %cr3");
}

void vmm_switch_pd (unsigned int *pd)
{
    current_pd = pd;
    __asm volatile ("mov %0, %%cr3" : : "r" (pd));
}

unsigned int *vmm_get_current_pd ()
{
    //return current_pd;
    unsigned int cr3;
    __asm volatile("mov %%cr3, %0" : "=r" (cr3));
    return (unsigned int *) cr3;
}

void vmm_init ()
{
    //make sure pmm_pop() is page-aligned!
    interrupt_install_handler(14, vmm_page_fault);
    
    kernel_pd = vmm_create_pd ();
    
    vmm_map_pt (0,0x400000, 0x400000);
    vmm_map_pt (0,0x800000, 0x800000);
    
    vmm_switch_pd (kernel_pd);
    vmm_enable_paging ();
    
    vmm_started = 1;
    
    printk("[vmm] init\n");
}