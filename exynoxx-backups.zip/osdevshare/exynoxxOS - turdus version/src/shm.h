#ifndef SHM_H
#define SHM_H


void shm_send_request (unsigned int *PD_want, unsigned int addr);
unsigned int shm_wait ();
void shm_init ();


#endif