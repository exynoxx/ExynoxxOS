#include "shm.h"
#include "task.h"
#include "vmm.h"

//typedef enum {SHM_WAITING, SHM_REQUEST_CONNECTION, SHM_REQUEST_SIZE} shm_status;

typedef struct {
    //unsigned int status : 1;
    unsigned int *me;
    unsigned int *want;
    unsigned int mountpoint;
    
} shm_header;

shm_header header[10];
unsigned int idx = 0;
unsigned int anynews = 0;

void shm_send_request (unsigned int *PD_want, unsigned int addr)
{
    header[idx].me = vmm_get_current_pd ();
    header[idx].want = PD_want;
    header[idx].mountpoint = addr;
    idx++;
    anynews = 1;
}

unsigned int shm_wait ()
{
    if (!anynews)
        return 0;
    if (idx <= 1)
        return 0;
    
    for (unsigned int i = 0; i < idx; i++) {
        for (unsigned int j = 0; j < idx; j++) {
            if (header[i].me != header[j].me)
                if (header[i].me == header[j].want)
                    if (header[i].want == header[j].me)
                    {
                        unsigned int *phys = 0;//pmm_pop_pt ();
                        vmm_map_pt (header[i].me, header[i].mountpoint, phys);
                        vmm_map_pt (header[j].me, header[j].mountpoint, phys);
                        vmm_flush_TLB ();
                        goto success;
                    }
        }
    }
    
    return 0;
    
success:
    anynews = 0;
    return 1;
}


void shm_init ()
{
    
    
}