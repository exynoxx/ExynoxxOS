#include "libc.h"
#include "dt.h"
#include "interrupt.h"
#include "monitor.h"
#include "task.h"
#include "pit.h"
#include <multiboot.h>
#include "heap.h"
#include <servers.h>
#include "shm.h"

void main(struct multiboot *mboot)
{
    gdt_install();
    idt_install();
    interrupt_install();
    monitor_clear();
    
    //pit_init (50);
    pmm_init (mboot);
    vmm_init ();
    //heap_init ();
    
    /*
    task_init ();
    task_create (a);
    task_create (b);
    task_create (c);
    task_create (server_mm);
    task_start ();
    */
    
    
    /*
     * kernel heap needed to run task
     * pmm optimizations + safety checks
     */
    
    unsigned int *a = (unsigned int *) pmm_pop ();
    unsigned int b = pmm_pop ();
    unsigned int c = pmm_pop ();
    unsigned int d = pmm_pop ();
    
    *a = 500;
    
    printk ("%x\n%x\n%x\n%x\n",a,b,c,d);
    

    for (;;);
}
