#include "../src/monitor.h"

void server_mm ()
{
    /*
    
    unsigned int *a = (unsigned int *) 0xC0000000;
    *a = 400;
    
    printk ("a: %i\n", *a);
     */
    
    while (1) {
    }
}