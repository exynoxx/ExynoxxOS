#include "tar.h"

struct tar_header
{
    char filename[100];
    char mode[8];
    char uid[8];
    char gid[8];
    char size[12];
    char mtime[12];
    char chksum[8];
    char typeflag[1];
    char zero[355]
} __attribute__ ((packed));

/*
unsigned char ascii_table [123] = {
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0, //20
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0, //40
    0,0,0,0,0,0,0,0,
    '0','1','2','3','4','5','6','7','8','9',':',';',
    '<','=','>','?','@',
    'A','B','C','D','E','F','G','H','I','J','K'
    ,'L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'
    ,0,0,0,0,0,0,
    'a','b','c','d','e','f','g','h','i','j','k','l','m','n',
    'o','p','q','r','s','t','u','v','w','x','y','z'
};

 */
 
unsigned int getsize(const char *in)
{
    
    unsigned int size = 0;
    unsigned int j;
    unsigned int count = 1;
    
    for (j = 11; j > 0; j--, count *= 8)
        size += ((in[j - 1] - '0') * count);
    
    return size;
    
}

void parse(unsigned int address)
{
    struct tar_header *header = (struct tar_header *) address;
    char *content;
    
    /*
     0) head 1
     1) cont
     2) head 2
     3) cont
     4) head 3
     */

    
    for (int i = 2; ; i += 2)
    {
        if (getsize(header->size) == 0x49249250)
        {
            printk ("END OF TAR\n\n");
            break;
        }
        
        //printk ("----------------------\n");
        printk ("[tar] file name: %s\n", header->filename);
        printk ("[tar] file size: %i\n", getsize(header->size));
        //printk ("[tar] file name: ");
 
        
        printk ("[tar] file content:\n");
        
        content = (char *) header + 512;
        printk ("%s\n", content);
        printk ("----------EOF-----------\n");
        
        header = (struct tar_header *) (address + 512*i);

    }
}

void tar_init (multiboot_mod *mod)
{
    printk ("[multiboot]          |   start  |    end   | size\n");
    printk ("[multiboot] %s | %x | %x | %x\n\n",    mod->string,
                                                    mod->mod_start,
                                                    mod->mod_end,
                                                    mod->mod_end - mod->mod_start
                                                    );
    //parse (mod->mod_start);
}
