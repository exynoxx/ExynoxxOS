#ifndef CBUFFER_H
#define CBUFFER_H

void cbuffer_init (unsigned int addr_start);
void cbuffer_add (unsigned int addr, unsigned int n);
unsigned int cbuffer_get (unsigned int n);


#endif