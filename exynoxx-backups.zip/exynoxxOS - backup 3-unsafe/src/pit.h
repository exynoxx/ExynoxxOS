#ifndef PIT_H
#define PIT_H

void pit_init ();

#endif