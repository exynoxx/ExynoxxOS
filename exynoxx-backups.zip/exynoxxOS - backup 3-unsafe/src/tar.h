#ifndef TAR_H
#define TAR_H

#include <multiboot.h>

void tar_init (multiboot_mod *mod);

#endif