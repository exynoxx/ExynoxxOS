#ifndef PMM_H
#define PMM_H

typedef struct _memblock
{
    unsigned int address;
    unsigned int size;
} memblock;

void            pmm_push_m (unsigned int addr, unsigned int n);
void            pmm_push (unsigned int addr);
unsigned int    pmm_pop_m (unsigned int n);
unsigned int    pmm_pop ();
unsigned int    pmm_popi ();
unsigned int    pmm_init (struct multiboot *mboot);

#endif