#ifndef MATH_H
#define MATH_H

#include "types.h"

uint32_t abs(uint32_t x);

#endif
