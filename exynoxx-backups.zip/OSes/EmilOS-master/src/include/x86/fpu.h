#ifndef FPU_H
#define FPU_H

void setup_x87_fpu();

#endif
