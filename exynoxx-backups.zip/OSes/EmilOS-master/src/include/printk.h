// 
// printk.h - Declares screen printing functions.
//            Written for JamesM's kernel development tutorials.
//

#ifndef PRINTK_H
#define PRINTK_H

void printk (const char *fmt, ...);

#endif
