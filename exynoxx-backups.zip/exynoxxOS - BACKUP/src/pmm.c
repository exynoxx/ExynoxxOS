#include <multiboot.h>
#include "pmm.h"
#include "libc.h"

#define GET_BIT(a)     (a >> 17)
#define GET_OFF(a)     ((a >> 12) % 32)
#define GET_ADDR(i,j)   (((i * 32) + j) * 4096)
#define SET_BIT(n,x)    (n |= (1 << x))
#define CLEAR_BIT(n,x)  (n &= ~(1 << x))

extern int end;
unsigned int kernel_end = (unsigned int) &end;

/*
 * addr /= 4096 [convert addr to page index]
 * addr /= 32 [find which entry it belongs to[32 bits on int]]
 * addr / 4096 / 32 == addr / (4096*32) == addr >> 17 [>> = /2]
 *
 * addr / 4096 [convert to page format] == addr >> 12
 * addr % 32 [devide with 32 to find entry. return remaining]
*/


/*
extern int end;
unsigned int kernel_end = (unsigned int) &end;
*/
/************************************************
 *          PAGE_BITMAP
 * 4GB / 4KB page / 32 bits in unsigned int
 * 32 bit CPU reads uint32_t as fast as uint8_t
 ************************************************
 *      SUPER_PAGE_BITMAP
 * super page each describing 4MB of mem
 * 1024 superpages / 32 bits = 32
 * if bit = 1 : this has at least one free page
 *************************************************/

unsigned int page_bitmap[32768];
unsigned int super_page_bitmap[32];

// MULTIBOOT MEM COLLECTER
void find_space (struct multiboot *mboot)
{
    unsigned int i = mboot->mmap_addr;
    unsigned int page_count = 0;
    
    while (i < (u32)mboot->mmap_addr + (u32)mboot->mmap_length)
    {
        multiboot_mmap *block = (multiboot_mmap *) i;
        
        // Does this entry specify usable RAM?
        if (block->type == 1)
        {
            (block->base_addr_low + 0x1000) & 0xfffff000;
            
            for (unsigned int j = block->base_addr_low; j < block->base_addr_low + block->length_low; j += 0x1000)
            {
                pmm_bitmap_add (j);
                page_count++;
            }
        }
        
        // The multiboot specification is strange in this respect - the size member does not include "size" itself in its calculations,
        // so we must add sizeof (uint32_t).
        i += block->size + sizeof (unsigned int);
    }
    printk ("[pmm] Added %i pages to bitmap.\n", page_count);
}

void pmm_bitmap_add (unsigned int addr)
{
    unsigned int i = GET_BIT (addr);
    unsigned int j = GET_OFF (addr);
    CLEAR_BIT (page_bitmap[i], j);
}

void pmm_mark_reserve (unsigned int addr)
{
    unsigned int i = GET_BIT (addr);
    
    for (unsigned int j = 0; j <= 31; j++, i++) {
        page_bitmap[i] = 0x0;
    }
}

//unsigned int addrr = 0x300000;

unsigned int pmm_alloc_page ()
{
    
    unsigned int i = 0;
    unsigned int j = 0;
    
    while(page_bitmap[i] == 0xFFFFFFFF)
    {
        i++;
    }
    
    for (; j <= 31; j++)
        if ((page_bitmap[i] & (1 << j)) == 0)
            break;
    
    SET_BIT(page_bitmap[i], j);
    return GET_ADDR(i,j);
    
    //return addrr += 0x1000;
}

void pmm_init (struct multiboot *mboot)
{
    for (int i = 0; i <= 32768; i++) {
        page_bitmap[i] = 0xFFFFFFFF;
    }
    
    find_space (mboot);
    pmm_mark_reserve (kernel_end);
    printk("[pmm] cleared: %x\n", kernel_end);
    
    
    printk("[pmm] init\n");
}
