#include "libc.h"
#include "dt.h"
#include "interrupt.h"
#include "monitor.h"
#include "task.h"
#include "pit.h"
#include <multiboot.h>
#include "heap.h"


int aa = 0;
int bb = 0;
int cc = 0;

void a ()
{
    unsigned int allo = 1;
    while (1){
        if (aa == 0) {
            printk ("a.");
            aa = 1;
            bb = 0;
            
            if (allo) {
                //vmm_map_pt (vmm_get_current_pd (), 0xC0000000, 0xa00000);
                unsigned int *hello = (unsigned int *) malloc (4);
                *hello = 100;
                
                printk ("malloc: %x is = %i", hello, *hello);
                allo = 0;
            }
        }
    }
}
void b ()
{
    while (1){
        if (bb == 0) {
            printk ("b.");
            bb = 1;
            cc = 0;
        }
        
    }
}
void c ()
{
    unsigned int activated = 0;
    while (1){
        if (cc == 0) {
            printk ("c.");
            cc = 1;
            aa = 0;
        }
    }
}

void main(struct multiboot *mboot)
{
    gdt_install();
    idt_install();
    interrupt_install();
    monitor_clear();
    
    //printk ("[kernel] size: %i\n", kernel_end - 0x00100000);
    
    //pit_init (50);
    pmm_init (mboot);
    vmm_init ();
    heap_init (0xC0000000);
    
    //task TEST
    
    task_init ();     //heap at 0xC0000000[virt], 0xa00000 [phys]
    task_create (a);
    task_create (b);
    task_create (c);
    task_start ();
    
    
    /*  RESUME
     
     just change task_init (0xC0000000, 0xa00000); 
     to have to parameters. page-fault!
     change heap mapping under tasking
     
     shared mem plans
     */

    
    

    

    /*
    //HEAP TEST
    unsigned int *a = (unsigned int *) malloc (4);
    *a = 500;
    unsigned int *b = (unsigned int *) malloc (4);
    unsigned int *c = (unsigned int *) malloc (4);
    
    printk ("a: %x\nb: %x\nc: %x\n",a,b,c);
    
    free(c);
    unsigned int *d = (unsigned int *) malloc (4);
    
    printk ("d: %x\n", d);
    */
    
    
    for (;;);
}
