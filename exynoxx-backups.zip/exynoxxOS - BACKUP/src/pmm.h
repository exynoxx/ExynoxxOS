#ifndef PMM_H
#define PMM_H

void            pmm_bitmap_add (unsigned int addr);
void            pmm_mark_reserve (unsigned int addr);
unsigned int    pmm_alloc_page ();
void            pmm_init (struct multiboot *mboot);

#endif